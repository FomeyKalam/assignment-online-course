var comCourse = [
    {
        "name" : "Machine Learning",
        "price" : 3000,
        "img" : "https://img-a.udemycdn.com/course/240x135/625204_436a_2.jpg"
    },
    {
        "name" : "Deep Learning",
        "price" : 4000,
        "img" : "https://img-a.udemycdn.com/course/240x135/625204_436a_2.jpg"

    },
    {
        "name" : "Python for Everybody",
        "price" : 3500,
        "img" : "https://img-a.udemycdn.com/course/240x135/625204_436a_2.jpg"
    },
    {
        "name" : "Introduction to data science",
        "price" : 3000,
        "img" : "https://img-a.udemycdn.com/course/240x135/625204_436a_2.jpg"
    },
    {
        "name" : "Applied Data Science",
        "price" : 4000,
        "img" : "https://img-a.udemycdn.com/course/240x135/625204_436a_2.jpg"
    },
    {
        "name" : "Google IT Support",
        "price" : 2500,
        "img" : "https://img-a.udemycdn.com/course/240x135/625204_436a_2.jpg"
    },
    {
        "name" : "Cloud Architecture",
        "price" : 3000,
        "img" : "https://img-a.udemycdn.com/course/240x135/1430746_2f43_9.jpg"
    },
    {
        "name" : "Cloud engineering",
        "price" : 4500,
        "img" : "https://img-a.udemycdn.com/course/240x135/625204_436a_2.jpg"
    },
    {
        "name" : "Web Development",
        "price" : 4000,
        "img" : "https://img-a.udemycdn.com/course/240x135/1430746_2f43_9.jpg"
    },
    {
        "name" : "Networking",
        "price" : 6000,
        "img" : "https://img-a.udemycdn.com/course/240x135/625204_436a_2.jpg"
    },
    {
        "name" : "Software Engineering",
        "price" : 6000,
        "img" : "https://img-a.udemycdn.com/course/240x135/1430746_2f43_9.jpg"
    },
    {
        "name" : "SQL",
        "price" : 4000,
        "img" : "https://img-a.udemycdn.com/course/240x135/625204_436a_2.jpg"
    },
    {
        "name" : "Graphics Design",
        "price" : 3000,
        "img" : "https://img-a.udemycdn.com/course/240x135/625204_436a_2.jpg"
    },
    {
        "name" : "Video Editing",
        "price" : 3000,
        "img" : "https://img-a.udemycdn.com/course/240x135/625204_436a_2.jpg"
    },
    {
        "name" : "Financial Market",
        "price" : 3000,
        "img" : "https://img-a.udemycdn.com/course/240x135/1430746_2f43_9.jpg"
    }
]
export default comCourse;