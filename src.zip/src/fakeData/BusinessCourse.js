var businessCourse =[
    {
        "name" : "Business Analyst",
        "price" : 2500,
        "img" : "https://img-a.udemycdn.com/course/240x135/1430746_2f43_9.jpg"
    },
    {
        "name" : "Finance and Accounting",
        "price" : 2000,
        "img" : "https://img-a.udemycdn.com/course/240x135/1430746_2f43_9.jpg"
    },
    {
        "name" : "Innovation",
        "price" : 2500,
        "img" : "https://img-a.udemycdn.com/course/240x135/764164_de03_2.jpg"
    },
    {
        "name" : "Investment",
        "price" : 2500,
        "img" : "https://img-a.udemycdn.com/course/240x135/764164_de03_2.jpg"
    },
    {
        "name" : "Project Management",
        "price" : 2500,
        "img" : "https://img-a.udemycdn.com/course/240x135/764164_de03_2.jpg"
    },
    {
        "name" : "HR",
        "price" : 2500,
        "img" : "https://img-a.udemycdn.com/course/240x135/764164_de03_2.jpg"
    },
    {
        "name" : "Social Media",
        "price" : 2500,
        "img" : "https://img-a.udemycdn.com/course/240x135/764164_de03_2.jpg"
    },
    {
        "name" : "Management And Leadership",
        "price" : 2500,
        "img" : "https://img-a.udemycdn.com/course/240x135/764164_de03_2.jpg"
    },
    {
        "name" : "Digital Marketing",
        "price" : 2500,
        "img" : "https://img-a.udemycdn.com/course/240x135/1430746_2f43_9.jpg"
    },
    {
        "name" : "Managerial Accounting",
        "price" : 2500,
        "img" : "https://img-a.udemycdn.com/course/240x135/1430746_2f43_9.jpg"
    },
    {
        "name" : "Leadership Communication",
        "price" : 2500,
        "img" : "https://img-a.udemycdn.com/course/240x135/764164_de03_2.jpg"
    },
    {
        "name" : "Principal of finance",
        "price" : 2500,
        "img" : "https://img-a.udemycdn.com/course/240x135/764164_de03_2.jpg"
    },
    {
        "name" :"Marketing Research",
        "price" : 2500,
        "img" : "https://img-a.udemycdn.com/course/240x135/1430746_2f43_9.jpg"
    },
    {
        "name" : "Investment Theory and Application",
        "price" : 2500,
        "img" : "https://img-a.udemycdn.com/course/240x135/764164_de03_2.jpg"
    },
    {
        "name" : "Financial Statement Analysis",
        "price" : 2500,
        "img" : "https://img-a.udemycdn.com/course/240x135/1430746_2f43_9.jpg"
    }

]
export default businessCourse;