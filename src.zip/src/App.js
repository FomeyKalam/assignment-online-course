import React from 'react';
import Header from './Components/Header/Header';
import CourseShop from './Components/CourseShop/CourseShop';

function App() {
  return (

    <div className="container">
     <Header></Header>
     <br/>
     <br/>
     <br/>
     <CourseShop></CourseShop>
    </div>
  );
}

export default App;
